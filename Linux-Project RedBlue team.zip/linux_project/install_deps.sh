#!/bin/bash
echo "[*] Updating packages..."
sudo apt update

echo "[*] Installing main tools..."
sudo apt install -y nmap sshpass netcat-openbsd mariadb-client curl openssh-client

echo "[*] Installing additional tools..."
sudo apt install -y net-tools iputils-ping dnsutils telnet

echo "[✓] All dependencies installed!"
echo ""
echo "Verifying..."
which nmap && echo "✓ nmap"
which sshpass && echo "✓ sshpass"
which nc && echo "✓ netcat"
which mysql && echo "✓ mysql"
which ssh && echo "✓ ssh"
which curl && echo "✓ curl"
