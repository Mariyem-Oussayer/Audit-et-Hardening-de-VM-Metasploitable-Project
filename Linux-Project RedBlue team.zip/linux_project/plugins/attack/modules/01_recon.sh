#!/bin/bash
################################################################################
# RED TEAM MODULE 1: RECONNAISSANCE
# Description: Parse le rapport Blue Team et énumère services
# Input: Target IP
# Output: Targets file, reconnaissance data
################################################################################

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOGS_DIR="$SCRIPT_DIR/../../logs/attack_sessions"
REPORTS_DIR="$(realpath "$SCRIPT_DIR/../../reports")"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p "$LOGS_DIR"

RECON_LOG="$LOGS_DIR/recon_${TIMESTAMP}.log"
TARGETS_FILE="$LOGS_DIR/targets_${TIMESTAMP}.txt"
RECON_DATA="$LOGS_DIR/recon_data.env"

log_info() { echo "[$(date '+%H:%M:%S')] [INFO] $1" | tee -a "$RECON_LOG"; }
log_success() { echo -e "${GREEN}[✓]${NC} $1" | tee -a "$RECON_LOG"; }
log_warning() { echo -e "${YELLOW}[!]${NC} $1" | tee -a "$RECON_LOG"; }
log_critical() { echo -e "${RED}[✗]${NC} $1" | tee -a "$RECON_LOG"; }

banner() {
    clear
    cat << "EOF"
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║    🔍 RED TEAM RECONNAISSANCE MODULE 🔍                       ║
║                                                                ║
║    Phase 1: Parse Blue Team Report + Service Enumeration     ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
EOF
}

parse_blue_report() {
    local blue_report
    blue_report=$(ls -1t "$REPORTS_DIR"/audit_scan.txt 2>/dev/null | head -n1)
    
    if [ -z "$blue_report" ]; then
        log_warning "No Blue Team report found, using nmap fallback"
        return 1
    fi
    
    log_info "Parsing Blue Team report: $blue_report"
    
    > "$TARGETS_FILE"
    
    # Extrait services du rapport
    if grep -q "TELNET" "$blue_report" 2>/dev/null; then
        echo "23|telnet|msfadmin" >> "$TARGETS_FILE"
        log_success "Found: Telnet on port 23"
    fi
    
    if grep -q "FTP" "$blue_report" 2>/dev/null; then
        echo "21|ftp|vsftpd" >> "$TARGETS_FILE"
        log_success "Found: FTP on port 21"
    fi
    
    if grep -q "SSH" "$blue_report" 2>/dev/null; then
        echo "22|ssh|openssh" >> "$TARGETS_FILE"
        log_success "Found: SSH on port 22"
    fi
    
    if grep -q "MySQL" "$blue_report" 2>/dev/null; then
        echo "3306|mysql|mysql" >> "$TARGETS_FILE"
        log_success "Found: MySQL on port 3306"
    fi
    
    if grep -q "IRC" "$blue_report" 2>/dev/null; then
        echo "6667|irc|unrealirc" >> "$TARGETS_FILE"
        log_success "Found: IRC on port 6667"
    fi
    
    return 0
}

run_nmap_scan() {
    local target=$1
    
    log_info "Running nmap scan on $target"
    
    > "$TARGETS_FILE"
    
    nmap -sV -sC -p 1-10000 "$target" 2>/dev/null | grep "open" | while read -r line; do
        port=$(echo "$line" | awk '{print $1}' | cut -d'/' -f1)
        service=$(echo "$line" | awk '{print $3}')
        version=$(echo "$line" | cut -d' ' -f4-)
        
        echo "$port|$service|$version" >> "$TARGETS_FILE"
        log_success "Found: $service on port $port"
    done
}

service_enumeration() {
    local target=$1
    
    if [ ! -s "$TARGETS_FILE" ]; then
        log_warning "No targets found"
        return 1
    fi
    
    log_info "Starting service-specific enumeration"
    
    while IFS='|' read -r port service version; do
        log_info "Checking $service on port $port"
        
        if nc -zv "$target" "${port%%/*}" 2>&1 | grep -q "succeeded"; then
            log_success "$service port $port is open and accessible"
            
            case "$service" in
                ssh|SSH)
                    banner=$(timeout 2 nc -v "$target" "${port%%/*}" 2>&1 | head -1)
                    log_info "SSH Banner: $banner"
                    echo "SSH_BANNER=$banner" >> "$RECON_DATA"
                    ;;
                ftp|FTP)
                    banner=$(timeout 2 nc -v "$target" "${port%%/*}" 2>&1 | head -1)
                    log_info "FTP Banner: $banner"
                    echo "FTP_BANNER=$banner" >> "$RECON_DATA"
                    ;;
                telnet|Telnet)
                    log_critical "TELNET DETECTED - CRITICAL!"
                    echo "HAS_TELNET=true" >> "$RECON_DATA"
                    ;;
                mysql|MySQL)
                    log_warning "MySQL detected - testing access"
                    echo "HAS_MYSQL=true" >> "$RECON_DATA"
                    ;;
            esac
        fi
    done < "$TARGETS_FILE"
}

generate_recon_data() {
    cat >> "$RECON_DATA" << EOF
# RED TEAM RECONNAISSANCE DATA
TARGET=$TARGET
TIMESTAMP=$TIMESTAMP
RECON_DATE=$(date)
TARGETS_COUNT=$(wc -l < "$TARGETS_FILE" 2>/dev/null || echo 0)
EOF
    
    # Ajoute flags pour chaque service
    grep -q "23|telnet" "$TARGETS_FILE" && echo "HAS_TELNET=true" >> "$RECON_DATA"
    grep -q "21|ftp" "$TARGETS_FILE" && echo "HAS_FTP=true" >> "$RECON_DATA"
    grep -q "22|ssh" "$TARGETS_FILE" && echo "HAS_SSH=true" >> "$RECON_DATA"
    grep -q "3306|mysql" "$TARGETS_FILE" && echo "HAS_MYSQL=true" >> "$RECON_DATA"
    grep -q "6667|irc" "$TARGETS_FILE" && echo "HAS_IRC=true" >> "$RECON_DATA"
}

main() {
    banner
    
    if [ -z "$1" ]; then
        read -p "$(echo -e ${CYAN})Enter target IP: " TARGET
    else
        TARGET=$1
    fi
    
    if ! [[ "$TARGET" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        log_critical "Invalid IP address"
        exit 1
    fi
    
    log_info "Target: $TARGET"
    log_info "Start time: $(date)"
    
    # Test connectivity
    if ! ping -c 1 "$TARGET" >/dev/null 2>&1; then
        log_critical "Target unreachable"
        exit 1
    fi
    
    log_success "Target is reachable"
    
    # Parse Blue Team report OR run nmap
    if ! parse_blue_report; then
        log_warning "Falling back to nmap scan"
        run_nmap_scan "$TARGET"
    fi
    
    # Service enumeration
    service_enumeration "$TARGET"
    
    # Generate recon data
    generate_recon_data
    
    # Summary
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    log_success "Reconnaissance completed"
    echo "Services found: $(wc -l < "$TARGETS_FILE")"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}Log: $RECON_LOG${NC}"
    echo -e "${GREEN}Data: $RECON_DATA${NC}"
    echo ""
    
    exit 0
}

main "$@"
