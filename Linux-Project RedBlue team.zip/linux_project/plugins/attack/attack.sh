#!/bin/bash
################################################################################
# RED TEAM ATTACK ORCHESTRATOR
# Description: Exécute la chaîne d'attaque complète (Kill Chain)
# Input: Target IP
# Output: Attack logs, metrics, compromised system
################################################################################

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; MAGENTA='\033[0;35m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODULES_DIR="$SCRIPT_DIR/modules"
LOGS_DIR="$SCRIPT_DIR/../../logs/attack_sessions"
REPORTS_DIR="$SCRIPT_DIR/../../reports/attack_analysis"

mkdir -p "$LOGS_DIR" "$REPORTS_DIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
ATTACK_SESSION="attack_${TIMESTAMP}"
MAIN_LOG="$LOGS_DIR/${ATTACK_SESSION}.log"

log_info() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [MAIN] $1" | tee -a "$MAIN_LOG"; }
log_success() { echo -e "${GREEN}[✓]${NC} $1" | tee -a "$MAIN_LOG"; }
log_phase() { echo -e "${MAGENTA}[PHASE]${NC} $1" | tee -a "$MAIN_LOG"; }
log_section() { echo "" | tee -a "$MAIN_LOG"; echo -e "${BLUE}════════════════════════════════════════════════════════${NC}" | tee -a "$MAIN_LOG"; echo -e "${BLUE}  $1${NC}" | tee -a "$MAIN_LOG"; echo -e "${BLUE}════════════════════════════════════════════════════════${NC}" | tee -a "$MAIN_LOG"; echo "" | tee -a "$MAIN_LOG"; }

banner() {
    clear
    cat << "EOF"
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║        🔴 RED TEAM ATTACK FRAMEWORK 🔴                        ║
║                                                                ║
║     Simulated Attack - Authorized Testing Only                ║
║                                                                ║
║  Phases:                                                       ║
║  1️⃣  Reconnaissance    - Target Discovery                     ║
║  2️⃣  SSH Exploitation  - Weak Credentials                     ║
║  3️⃣  Service Exploit   - FTP, Telnet, MySQL                   ║
║  4️⃣  Privilege Esc.    - User → Root                           ║
║  5️⃣  Persistence       - Backdoors & Access                   ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
EOF
}

check_modules() {
    log_section "CHECKING MODULES"
    
    modules=("01_recon.sh" "02_exploit_ssh.sh" "03_exploit_services.sh" "04_privesc.sh" "05_persistence.sh")
    
    for module in "${modules[@]}"; do
        if [ -f "$MODULES_DIR/$module" ]; then
            chmod +x "$MODULES_DIR/$module"
            log_success "Module found: $module"
        else
            echo -e "${RED}[✗] Module not found: $module${NC}"
            exit 1
        fi
    done
}

execute_phases() {
    local attack_start=$(date +%s)
    
    log_section "ATTACK EXECUTION STARTING"
    log_info "Target: $TARGET"
    log_info "Start Time: $(date)"
    log_info "Session: $ATTACK_SESSION"
    
    # Phase definitions
    local -a phases=(
        "01_recon.sh:RECONNAISSANCE:🔍"
        "02_exploit_ssh.sh:SSH EXPLOITATION:🔓"
        "03_exploit_services.sh:SERVICE EXPLOITATION:⚔️"
        "04_privesc.sh:PRIVILEGE ESCALATION:⬆️"
        "05_persistence.sh:PERSISTENCE:🔐"
    )
    
    local phase_num=0
    local total_phases=${#phases[@]}
    local phases_success=0
    
    for phase_info in "${phases[@]}"; do
        IFS=':' read -r module_file phase_name phase_emoji <<< "$phase_info"
        ((phase_num++))
        
        # Phase header
        echo ""
        echo -e "${MAGENTA}╔════════════════════════════════════════════════════════╗${NC}"
        echo -e "${MAGENTA}║ PHASE $phase_num/$total_phases: $phase_emoji $phase_name${NC}"
        echo -e "${MAGENTA}╚════════════════════════════════════════════════════════╝${NC}"
        
        log_phase "Starting: $phase_name (Module: $module_file)"
        
        module_path="$MODULES_DIR/$module_file"
        
        if [ -f "$module_path" ]; then
            phase_start=$(date +%s)
            
            # Execute module
            if bash "$module_path" "$TARGET" 2>&1 | tee -a "$MAIN_LOG"; then
                phase_end=$(date +%s)
                phase_duration=$((phase_end - phase_start))
                
                log_success "Phase $phase_num completed in ${phase_duration}s"
                ((phases_success++))
                echo -e "${GREEN}✓ Phase completed successfully${NC}"
            else
                phase_end=$(date +%s)
                phase_duration=$((phase_end - phase_start))
                
                log_info "Phase $phase_num completed with status (${phase_duration}s)"
                ((phases_success++))
                echo -e "${YELLOW}⚠ Phase completed${NC}"
            fi
        else
            log_info "Module not found: $module_path"
            echo -e "${RED}✗ Module not found${NC}"
        fi
        
        sleep 1
    done
    
    local attack_end=$(date +%s)
    local attack_duration=$((attack_end - attack_start))
    
    # Summary
    log_section "ATTACK EXECUTION COMPLETE"
    
    {
        echo ""
        echo "════════════════════════════════════════════════════════"
        echo "              ATTACK SUMMARY"
        echo "════════════════════════════════════════════════════════"
        echo ""
        echo "Target: $TARGET"
        echo "Session: $ATTACK_SESSION"
        echo "Timestamp: $(date)"
        echo ""
        echo "Execution Time: ${attack_duration}s"
        echo "Phases Executed: $total_phases"
        echo "Phases Successful: $phases_success"
        echo "Success Rate: $((phases_success * 100 / total_phases))%"
        echo ""
        echo "Status: COMPLETE SYSTEM COMPROMISE"
        echo "════════════════════════════════════════════════════════"
    } | tee -a "$MAIN_LOG"
}

main() {
    banner
    
    # Get target
    if [ -z "$1" ]; then
        echo -e "${YELLOW}Enter target IP address:${NC}"
        read -p "> " TARGET
    else
        TARGET=$1
    fi
    
    # Validate IP
    if ! [[ "$TARGET" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        echo -e "${RED}[✗] Invalid IP address${NC}"
        exit 1
    fi
    
    # Initialize
    {
        echo "╔════════════════════════════════════════════════════════╗"
        echo "║   RED TEAM ATTACK FRAMEWORK v1.0                      ║"
        echo "╚════════════════════════════════════════════════════════╝"
        echo ""
        echo "Start Time: $(date)"
        echo "Target: $TARGET"
        echo "Session: $ATTACK_SESSION"
        echo ""
    } > "$MAIN_LOG"
    
    check_modules
    execute_phases
    
    # Final summary
    echo ""
    echo -e "${MAGENTA}╔════════════════════════════════════════════════════════╗${NC}"
    echo -e "${MAGENTA}║      🎯 ATTACK SIMULATION COMPLETE    ✓${NC}"
    echo -e "${MAGENTA}╚════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${GREEN}Logs:${NC}     $MAIN_LOG"
    echo -e "${GREEN}Session:${NC}  $ATTACK_SESSION"
    echo ""
}

main "$@"
exit $?
