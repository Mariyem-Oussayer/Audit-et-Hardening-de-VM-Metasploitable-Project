#!/bin/bash
# FICHIER: plugins/scan/audit_interne.sh
# Auteur: Etudiant 1
# Description: Vérifie la configuration INTERNE via SSH (Version Compatible Metasploitable)

# 1. Configuration
BASE_DIR=$(dirname "$(realpath "$0")")
source "$BASE_DIR/../../config/scoring.conf"
RAPPORT="$BASE_DIR/../../reports/audit_scan.txt"

TARGET_IP=$1
USER="msfadmin"
PASS="msfadmin"

# --- LE FIX EST ICI ---
# On force SSH à accepter les anciennes clés (rsa/dss) de Metasploitable
SSH_OPTS="-o StrictHostKeyChecking=no -o HostKeyAlgorithms=+ssh-rsa -o PubkeyAcceptedKeyTypes=+ssh-rsa"

echo -e "\n[*] Lancement de l'Audit Interne (SSH)..."

# 2. Vérification SSH (Root Login)
# On utilise $SSH_OPTS pour passer la sécurité moderne de Kali
CHECK_ROOT=$(sshpass -p "$PASS" ssh $SSH_OPTS $USER@$TARGET_IP "grep '^PermitRootLogin' /etc/ssh/sshd_config" 2>/dev/null)

# Debug (pour voir si ça marche)
# echo "Debug SSH: $CHECK_ROOT"

if [[ "$CHECK_ROOT" == *"yes"* ]]; then
    echo -e "${RED}[FAIL] SSH : Connexion Root autorisée ! (Faille Critique)${NC}"
    echo "[FAIL] INTERNE: Root Login SSH autorisé" >> "$RAPPORT"
else
    # Si la variable est vide, c'est que la connexion a encore échoué
    if [ -z "$CHECK_ROOT" ]; then
        echo -e "${YELLOW}[ERREUR] Impossible de se connecter en SSH. Vérifiez le réseau.${NC}"
    else
        echo -e "${GREEN}[PASS] SSH : Connexion Root désactivée${NC}"
        echo "[PASS] INTERNE: Root Login SSH sécurisé" >> "$RAPPORT"
    fi
fi

# 3. Vérification Kernel (IP Forwarding)
SYSCTL=$(sshpass -p "$PASS" ssh $SSH_OPTS $USER@$TARGET_IP "sysctl -n net.ipv4.ip_forward" 2>/dev/null)

if [[ "$SYSCTL" == "1" ]]; then
    echo -e "${RED}[FAIL] Kernel : IP Forwarding activé (Risque)${NC}"
    echo "[FAIL] INTERNE: Kernel IP Forwarding activé" >> "$RAPPORT"
else
     if [ -z "$SYSCTL" ]; then
        echo -e "${YELLOW}[ERREUR] Impossible de lire le Kernel.${NC}"
    else
        echo -e "${GREEN}[PASS] Kernel : IP Forwarding désactivé${NC}"
        echo "[PASS] INTERNE: Kernel sécurisé" >> "$RAPPORT"
    fi
fi
echo -e "${BLUE}[INFO] Audit interne terminé.${NC}"
