#!/bin/bash
# FICHIER: plugins/scan/gen_html.sh
# Auteur: Etudiant 1
# Description: Convertit le rapport texte en HTML stylé

BASE_DIR=$(dirname "$(realpath "$0")")
INPUT="$BASE_DIR/../../reports/audit_scan.txt"
OUTPUT="$BASE_DIR/../../reports/rapport_final.html"

# 1. Écriture de l'en-tête HTML (Design CSS)
cat <<EOF > "$OUTPUT"
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Rapport de Sécurité - Projet 5</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f2f5; margin: 0; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        h1 { color: #2c3e50; text-align: center; border-bottom: 2px solid #ecf0f1; padding-bottom: 15px; }
        .status-box { padding: 15px; margin-bottom: 10px; border-radius: 6px; border-left: 5px solid; }
        
        .fail { background-color: #fadbd8; color: #c0392b; border-color: #e74c3c; font-weight: bold; }
        .pass { background-color: #d4efdf; color: #27ae60; border-color: #2ecc71; }
        .info { background-color: #d6eaf8; color: #2980b9; border-color: #3498db; }
        
        .score-box { text-align: right; font-size: 1.5em; font-weight: bold; margin-top: 30px; color: #2c3e50; background: #ecf0f1; padding: 15px; border-radius: 8px; }
        .footer { text-align: center; margin-top: 20px; color: #7f8c8d; font-size: 0.9em; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🛡️ Rapport d'Audit de Sécurité</h1>
        <p><strong>Date du scan :</strong> $(date)</p>
        <hr>
EOF

# 2. Lecture et conversion du contenu
while IFS= read -r line; do
    # On nettoie les codes couleurs du terminal pour le HTML
    clean_line=$(echo "$line" | sed 's/\x1b\[[0-9;]*m//g')

    if [[ "$clean_line" == *"[FAIL]"* ]]; then
        echo "<div class='status-box fail'>$clean_line</div>" >> "$OUTPUT"
    elif [[ "$clean_line" == *"[PASS]"* ]]; then
        echo "<div class='status-box pass'>$clean_line</div>" >> "$OUTPUT"
    elif [[ "$clean_line" == *"[INFO]"* ]]; then
        echo "<div class='status-box info'>$clean_line</div>" >> "$OUTPUT"
    elif [[ "$clean_line" == *"NOTE DE SÉCURITÉ"* ]]; then
        echo "<div class='score-box'>$clean_line</div>" >> "$OUTPUT"
    fi
done < "$INPUT"

# 3. Pied de page
cat <<EOF >> "$OUTPUT"
        <div class="footer">Généré automatiquement par le Framework SecuProject v1.0</div>
    </div>
</body>
</html>
EOF

echo -e "\n[+] Rapport HTML généré : $OUTPUT"
