#!/bin/bash
# FICHIER: plugins/scan/scan.sh
# Auteur: Etudiant 1 (Blue Team)
# Description: Moteur d'audit automatique pour Metasploitable 2

# 1. CHARGEMENT DE LA CONFIGURATION
BASE_DIR=$(dirname "$(realpath "$0")")
source "$BASE_DIR/../../config/scoring.conf"

# Définition des fichiers de sortie
LOG_FILE="$BASE_DIR/../../logs/scan.log"
RAPPORT="$BASE_DIR/../../reports/audit_scan.txt"

# Initialisation de la note
NOTE=100

# 2. PRÉPARATION DU RAPPORT
echo "===============================================" > "$RAPPORT"
echo "   RAPPORT D'AUDIT DE SÉCURITÉ - PROJET 5" >> "$RAPPORT"
echo "===============================================" >> "$RAPPORT"
echo "Date du scan : $(date)" >> "$RAPPORT"
echo "-----------------------------------------------" >> "$RAPPORT"

# Fonction utilitaire
log_result() {
    TYPE=$1    # FAIL, PASS, INFO
    MSG=$2     # Message
    PTS=$3     # Points

    if [ "$TYPE" == "FAIL" ]; then
        echo -e "${RED}[FAIL] $MSG ($PTS pts)${NC}"
        echo "[FAIL] $MSG" >> "$RAPPORT"
        NOTE=$((NOTE + PTS))
    elif [ "$TYPE" == "PASS" ]; then
        echo -e "${GREEN}[PASS] $MSG (+5 pts)${NC}"
        echo "[PASS] $MSG" >> "$RAPPORT"
        if [ $NOTE -lt 100 ]; then NOTE=$((NOTE + 5)); fi
    else
        echo -e "${BLUE}[INFO] $MSG${NC}"
        echo "[INFO] $MSG" >> "$RAPPORT"
    fi
}

# 3. VÉRIFICATION DE LA CIBLE
TARGET_IP=$1
if [ -z "$TARGET_IP" ]; then
    echo -e "${YELLOW}Usage: ./scan.sh <IP_CIBLE>${NC}"
    exit 1
fi

log_result "INFO" "Cible verrouillée : $TARGET_IP" 0

# Test Ping
ping -c 1 $TARGET_IP &> /dev/null
if [ $? -ne 0 ]; then
    echo -e "${RED}[ERREUR] La cible ne répond pas !${NC}"
    exit 1
fi

# 4. ANALYSE DES PORTS (Le vrai travail commence ici !)
echo -e "\n[*] Lancement des scans Nmap..."

# --- TEST 1 : TELNET (Port 23) ---
nmap -p 23 $TARGET_IP | grep "open" &> /dev/null
if [ $? -eq 0 ]; then
    log_result "FAIL" "Service TELNET ouvert (23) - Trafic non chiffré !" $SCORE_CRITIQUE
else
    log_result "PASS" "Telnet est désactivé" $SCORE_BONUS
fi

# --- TEST 2 : FTP (Port 21) ---
nmap -p 21 $TARGET_IP | grep "open" &> /dev/null
if [ $? -eq 0 ]; then
    log_result "FAIL" "Service FTP ouvert (21) - Risque de Backdoor" $SCORE_ELEVE
else
    log_result "PASS" "FTP est fermé" $SCORE_BONUS
fi

# --- TEST 3 : VNC (Port 5900) ---
nmap -p 5900 $TARGET_IP | grep "open" &> /dev/null
if [ $? -eq 0 ]; then
    log_result "FAIL" "Service VNC ouvert (5900) - Accès distant risqué" $SCORE_MOYEN
fi

# --- TEST 4 : IRC (Port 6667) ---
nmap -p 6667 $TARGET_IP | grep "open" &> /dev/null
if [ $? -eq 0 ]; then
    log_result "FAIL" "Service IRC ouvert (6667) - Faille UnrealIRCd possible" $SCORE_CRITIQUE
fi
# --- AUDIT INTERNE (Nouveau !) ---
# On appelle le script audit_interne.sh qu'on vient de créer
bash "$BASE_DIR/audit_interne.sh" "$TARGET_IP"
# 5. CONCLUSION
echo "" >> "$RAPPORT"
echo "-----------------------------------------------" >> "$RAPPORT"
echo "NOTE DE SÉCURITÉ FINALE : $NOTE / 100" >> "$RAPPORT"
echo "-----------------------------------------------" >> "$RAPPORT"

echo -e "\n${YELLOW}>>> AUDIT TERMINÉ.${NC}"
echo -e "Note attribuée : ${YELLOW}$NOTE / 100${NC}"
echo -e "Rapport généré : reports/audit_scan.txt"
# --- GÉNÉRATION HTML ---
bash "$BASE_DIR/gen_html.sh"

echo -e "\n${YELLOW}>>> AUDIT TERMINÉ ET RAPPORT WEB CRÉÉ !${NC}"
